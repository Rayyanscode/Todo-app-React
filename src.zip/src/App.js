import React from 'react'
import Todo from './component/todo';

function App() {
  return (
    <>
    <Todo/>
    </>
  );
}

export default App;
